package com.capgemini.aop.examples;

public class EmployeeService {
	
	public void addEmployee(){
		System.out.println("Employee service add employee BL");
	}
	
	public void deleteEmployee(){
		System.out.println("Employee service delete employee BL");
	}

}
