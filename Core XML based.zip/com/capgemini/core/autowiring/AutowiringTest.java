package com.capgemini.core.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutowiringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new 
				ClassPathXmlApplicationContext
				("com\\capgemini\\core\\autowiring\\autowiringbeans.xml");
		
		Employee emp = (Employee) context.getBean("employee");
		//Employee emp1 = 
		//		context.getBean("employee", Employee.class);
		
		//byName -> will refer that var name declaration in xml file
		//address var exists in xml, so address will have object
		//address1 var does not exists in xml, and so 
		//getAddress1() will be null
		System.out.println(emp.getAddress());
		System.out.println(emp.getAddress1());
		
		//byType -> will check the object type
		//Here both address and address1 are of Address type
		//and Address type is registered in xml file, so
		//address and address1 both  will refer the same bean 
		//declaration in xml file
		
		//constructor -> it will use construtor based autowiring
		
		//autodetect -> will choose either byType or constructor
		
			//if default constructor exists, then it will choose 
						//byType approach
			// if no default constructor, then constructor based 
								//autowirng
		
	}

}
