package com.capgemini.core.autowiring;

public class Employee {

	public Employee(){
		
	}
	
	//constructor based dI
	public Employee(int empId, String name, double salary, 
			Address address) {
		
		this.empId = empId;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}
	
	public void initEmployee() throws Exception{
		System.out.println("Business logic will be executed " +
				"after all properties has been set......");
		
		if (empId <0) {
			throw new Exception("sadsadsadsad");
		}
	}
	
	public void destroy(){
		System.out.println("Business logic wil;l be executed before object is going to be garbage collectied");
	}
	
	public Employee(int empId, Address address) {
		
		this.empId = empId;
		this.address = address;
	}



	private int empId;
	private String name;
	private double salary;
	
	//dedendency object
	//association
	private Address address;
	private Address address1;
	//private Student student;
	
	public Address getAddress1() {
		return address1;
	}

	public void setAddress1(Address address1) {
		this.address1 = address1;
	}

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	
}
