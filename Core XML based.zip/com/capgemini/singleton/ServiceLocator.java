package com.capgemini.singleton;

import com.capgemini.core.Address;
import com.capgemini.core.Employee;

//register all services at one place
// this class only responsible for returning the servic/bean instances
//Single point entry to create the instances for all beans
public class ServiceLocator {
	
	public Employee getEmployee(){
		return new Employee();
	}
	
	public Address getAddress() {
		return new Address();
	}
	
	/*
	 * public EmployeeService getEmployeeService() {
		return new EmployeeService();
	}
	
	public CartService getCartService() {
		return new CartService();
	}
	
	 */

}
