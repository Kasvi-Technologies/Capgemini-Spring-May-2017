package com.capgemini.annotationsex.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component -> to avoid registering bean in xml file
//default var name will be classname but starting with small letter
//employee


//@Component("employee123")

@Component
public class Employee {

	private int empId;
	private String name;
	private double salary;
	private Address address;
	
	public int getEmpId() {
		return empId;
	}
	//dependency-check="simple"
	//<property name="empId" value="100/>
	
	@Required
	@Value("100")
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	
	@Value("Annotations Based")
	public void setName(String name) {
		this.name = name;
	}
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	//by fault will check for byType approach
	//dependency-check="objects"
	@Required
	@Autowired
	@Qualifier("address1")
	public void setAddress(Address address2) {
		this.address = address2;
	}
	
}
