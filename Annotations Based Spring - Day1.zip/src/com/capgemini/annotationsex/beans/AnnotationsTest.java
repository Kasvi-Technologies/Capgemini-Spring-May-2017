package com.capgemini.annotationsex.beans;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class AnnotationsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new 
				ClassPathXmlApplicationContext
				("com\\capgemini\\annotationsex\\beans\\annotationexamples.xml");
		
		Employee emp = (Employee)context.getBean("employee");
		System.out.println(emp.getEmpId());
		System.out.println(emp.getName());
		System.out.println(emp.getAddress().getCity());
	}

}





