package com.capgemini.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.capgemini.core.Employee;
import com.capgemini.singleton.DBProperties;

public class CoreTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//retrieve the employee instance using spring
		
		//BeanFactory (I) is the base class, which  holds all beans related informations.
		//ApplicationContext is the subclass of beanfactory
		
		BeanFactory beanFactory = new XmlBeanFactory
								(new FileSystemResource("src/com/capgemini/core/beans.xml"));
		
		
		// Employee employee = new Employee();
		// employee.setEmpId(100);
		// employee.setName("Capgemini Employee");
		// employee.setSalary(100000);
		
		
		// Address addr = new Address();
		// addr.setCity();
		// addr.setState();
		// employee.setAddress(addr);
		
		Employee emp = (Employee) beanFactory.getBean("employee");  // create the instance , in lazy initialization 		
		//if we specify lazy-init true, then beans will be created explicitly at the time of calling 
		//getBean() method
	
		System.out.println(emp.getEmpId() + " " + emp.getName() + " " + emp.getSalary());
		System.out.println("employee address" + emp.getAddress());
		
		System.out.println(emp.getAddress().getCity() + " " + emp.getAddress().getState());
		
		
		Employee emp1 = (Employee) beanFactory.getBean("employee1");
		System.out.println(emp1.getEmpId() + " " + emp1.getName() + " " + emp1.getSalary());
		System.out.println(emp1.getAddress());
		
		System.out.println("Using Constructor based DI");
		
		Employee emp2 = (Employee) beanFactory.getBean("employeeUsingConst");
		System.out.println("employee constructor address" + emp2.getAddress());

		System.out.println("loading singleton class using spring xml");		
		DBProperties dBPropertiesInstance = (DBProperties) beanFactory.getBean("dBPropertiesInstance");
		System.out.println(dBPropertiesInstance);
		
		
		
	}
}
