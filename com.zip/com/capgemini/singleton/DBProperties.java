package com.capgemini.singleton;

//Singleton class example
public class DBProperties {
	
	private DBProperties(){
		
	}
	
	private static DBProperties dBProperties = null;

	public static synchronized DBProperties createInstance() {
		
		if (dBProperties ==null) {
			dBProperties = new DBProperties();
		}
		
		return dBProperties;
	}
	
}

/**
	<bean class="com.capgemini.singleton.DBProperties" factory-method="createInstance"
			id="dBPropertiesInstance" />
	
	DBProperties dbProp = (DBProperties) factory.getBean("dBPropertiesInstance");
*/