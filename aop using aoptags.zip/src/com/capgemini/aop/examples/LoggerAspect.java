package com.capgemini.aop.examples;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Around;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

//Before starting the method  
//MethodBeforeAdvice
//after completion of the method 
//AfterReturningAdvice
//when ever exception throws from the application -> 
//ThrowsAdvice
//around - > before calling and after completion of the method
//MethodInterceptor 

public class LoggerAspect implements MethodBeforeAdvice{

	@Override
	public void before(Method name, 
					   Object[] parameters, Object target)
			throws Throwable {
		
		//Logger related business logic to be executed before
		//calling the actual method...
		System.out.println("Logger aspect business logic");
		System.out.println(target); //original object
		System.out.println(parameters); 
		//method arguments, 
		System.out.println(name); 
		//original method name like addEmployee or deleteEmployee
		
	}
	
	public void doBefore(JoinPoint point){
		System.out.println("do before mthos logic in aspect....");
	}
	
}
