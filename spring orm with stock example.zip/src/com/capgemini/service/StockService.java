package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hibernate.beans.Stock;
import com.capgemini.hibernate.beans.StockDAO;

@Service
public class StockService {

	@Autowired
	private StockDAO stockDAO;
	
	public void addStock(Stock s){
		stockDAO.addStock(s);
	}
}
