package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.ProductDAO;
import com.capgemini.hibernate.beans.Product;

@Service
public class ProductService {
	
	@Autowired
	private ProductDAO productDAO;
	
	public void addProduct(Product p){
		this.productDAO.addProduct(p);
	}
	
	public void deleteProduct(Product p){
		this.productDAO.deleteProduct(p);
	}

	public Product fetchProductById(int productId){
		return this.productDAO.fetchProductById(productId);
	}
	
	
}
