package com.capgemini.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;

import org.springframework.stereotype.Repository;

import com.capgemini.hibernate.beans.Product;

@Repository
public class ProductDAO {
	
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	//sessionFactory object from xml file will be injected to this method
	//and creates the hibenate template
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory){
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}

	public void addProduct(Product p){
		//Hibernate logic
		this.getHibernateTemplate().save(p);  //insert into product
	}
	
	public void deleteProduct(Product p){
		this.getHibernateTemplate().delete(p); //delete from product
	}

	public Product fetchProductById(int productId){
		List productList = this.getHibernateTemplate()
									.find("from Product p where p.productId = ? ",productId);
		//select & from product where ...
		if (productList!=null && productList.size() > 0)
			return (Product) productList.get(0);
		else 
			return null;
	}

}
