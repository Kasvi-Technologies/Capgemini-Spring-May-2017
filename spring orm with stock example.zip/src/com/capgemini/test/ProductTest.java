package com.capgemini.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.hibernate.beans.Product;
import com.capgemini.service.ProductService;

public class ProductTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
				"springhibernate.xml");
		
		Product product = new Product();
		product.setName("annotations...");
		product.setPrice(200);
		product.setQty(2);
		
		ProductService pService = (ProductService) 
										context.getBean("productService");
		
		pService.addProduct(product);
		
		System.out.println("..............................Done.........");
	}

}
