package com.capgemini.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.hibernate.beans.Product;
import com.capgemini.service.ProductService;

public class FetchProductTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
				"springhibernate.xml");
	
		
		ProductService pService = (ProductService) 
										context.getBean("productService");
		
		Product p = pService.fetchProductById(1);
		
		System.out.println("..............................Done........." + p.getName());
	}

}
