package com.capgemini.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.hibernate.beans.Product;
import com.capgemini.hibernate.beans.Stock;
import com.capgemini.service.ProductService;
import com.capgemini.service.StockService;

public class StockTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
				"springhibernate.xml");
		
		Stock stock = new Stock();
		
		stock.setName("sadsad");
		stock.setPrice(2321);
		
		StockService sService = (StockService) 
										context.getBean("stockService");
		
		sService.addStock(stock);
		
		System.out.println("..............................Done.........");
	}

}
