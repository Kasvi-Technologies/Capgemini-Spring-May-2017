package com.capgemini.hibernate.beans;

import javax.persistence.Id;

import javax.persistence.*;

@Entity
@Table(name="product")
public class Product {
	
	private int productId;
	private String name;
	private double price;
	private int qty;
	
	@Id
	@Column(name="productid")
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getProductId() {
		return productId;
	}
	
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	@Column(name="productname")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Column
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	
}
