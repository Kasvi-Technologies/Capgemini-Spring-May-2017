package com.capgemini.hibernate.beans;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StockDAO {	
	//HibernateTemplate is the class for Spring and Hibernate integration
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	//sessionFactory object from xml file will be injected to this method
	//and creates the hibenate template
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory){
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	public void addStock(Stock s){
		this.getHibernateTemplate().save(s);
	}


}
