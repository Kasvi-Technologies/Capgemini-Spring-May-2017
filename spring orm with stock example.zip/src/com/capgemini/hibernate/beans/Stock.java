package com.capgemini.hibernate.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//ORM - object relational mapping
//Hibernate is a ORM tool

@Entity
@Table(name="stock")
public class Stock {
	private int stockId;
	private String name;
	private double price;	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="stockid")
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	@Column(name="stockname")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="price")
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
