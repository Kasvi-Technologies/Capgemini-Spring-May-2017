package com.capgemini.aop.examples;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPTagsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
				"com\\capgemini\\aop\\examples\\usingaoptags.xml");
		
		EmployeeService empService = (EmployeeService) 
			context.getBean("employeeService");
		
		empService.addEmployee();
		
		empService.deleteEmployee();
	}

}
