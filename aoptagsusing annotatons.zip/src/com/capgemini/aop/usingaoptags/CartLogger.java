package com.capgemini.aop.usingaoptags;

import org.aspectj.lang.JoinPoint;

public class CartLogger {
	
	public void beforeProceedToCart(JoinPoint point){
		System.out.println("In Cart Logger class beforeProceedToCart");
	}

	
	public void afterAddToCart(JoinPoint point){
		System.out.println("In Cart Logger class afterAddToCart");
	}
}
