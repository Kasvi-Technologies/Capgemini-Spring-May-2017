package com.capgemini.aop.usingaoptags;

public class CartService {

	//Before calling this method, we will call logger aspect method
	public void proceedToCheckOut(){
		System.out.println("In proceed to check out");
	}
	
	//after completion of the method, will call logger aspect ,method..
	public void addToCart(){
		System.out.println("In addto cart method");
	}
}
