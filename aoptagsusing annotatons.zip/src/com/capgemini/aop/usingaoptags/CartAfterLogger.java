package com.capgemini.aop.usingaoptags;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class CartAfterLogger {
	
	@After("execution(* com.capgemini.aop.usingaoptags.CartService.addToCart(..))")
	public void afterPerform(JoinPoint point){
		System.out.println("CartAfterlogger class afterperoform method.....");
		
	}

}
