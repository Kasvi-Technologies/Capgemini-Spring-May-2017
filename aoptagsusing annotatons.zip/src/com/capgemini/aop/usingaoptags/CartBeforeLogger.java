package com.capgemini.aop.usingaoptags;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class CartBeforeLogger {

	@Before(
"execution(* com.capgemini.aop.usingaoptags.CartService.proceedToCheckOut(..))")
	public void performBefore(JoinPoint point){
		System.out.println("In Cart Before looger class perform before method");
	}
	
}
