package com.capgemini.aop.usingaoptags;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CartAnnotationsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
				"com\\capgemini\\aop\\usingaoptags\\aoptagsannotations.xml");
		
	CartService cService = (CartService) context.getBean("cartService");
	cService.proceedToCheckOut();
	cService.addToCart();
		

	}

}
